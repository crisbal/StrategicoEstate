package javaGame;

public class Tecnologies {
	
	/* Primo valore: NESSUN PLAYER(VALORE INUTILE), Secondo valore: Player1, Terzo valore: Player2 */
	
	/* Implementate */
	public static boolean[] soldatoPiuAttacco = {false, false, true};
	public static boolean[] carroPiuAttacco = {false, false, false};
	public static boolean[] soldatoPiuDifesa = {false, true, false};
	public static boolean[] carroPiuDifesa = {false, false, false};
	
	/* Non implementate */
	public static boolean[] veicoloVsFanteria = {false, false, false};
}
